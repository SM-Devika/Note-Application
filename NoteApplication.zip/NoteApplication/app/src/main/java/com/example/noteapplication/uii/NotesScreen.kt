package com.example.notesapp.uii

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.notesapp.data.Note
import com.example.notesapp.viewmodel.NoteViewModel
import androidx.compose.runtime.livedata.observeAsState

@Composable
fun NotesScreen(noteViewModel: NoteViewModel = viewModel()) {
    val notes by noteViewModel.allNotes.observeAsState(emptyList())
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var isEditing by remember { mutableStateOf(false) }
    var editingNoteId by remember { mutableStateOf<Int?>(null) }

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Title") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                if (title.isNotBlank() && description.isNotBlank()) {
                    val note = Note(id = editingNoteId ?: 0, title = title, description = description)
                    if (isEditing) noteViewModel.update(note) else noteViewModel.insert(note)
                    title = ""
                    description = ""
                    isEditing = false
                    editingNoteId = null
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isEditing) "Update Note" else "Add Note")
        }
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn {
            items(notes, key = { it.id }) { note ->
                NoteItem(
                    note = note,
                    onDelete = { noteViewModel.delete(it) },
                    onEdit = {
                        title = it.title
                        description = it.description
                        isEditing = true
                        editingNoteId = it.id
                    }
                )
            }
        }
    }
}
